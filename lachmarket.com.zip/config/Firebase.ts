import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBemHywTaVBXmK64c5j0PnSYG_02FMbtPk",

  authDomain: "lachmarket-34ace.firebaseapp.com",

  projectId: "lachmarket-34ace",

  storageBucket: "lachmarket-34ace.appspot.com",

  messagingSenderId: "836008583621",

  appId: "1:836008583621:web:5ad904dbf6393ba751ebac",

  measurementId: "G-FVCQG5VGZT",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
// export const db = getFirestore(app);

export const auth = getAuth(app);
